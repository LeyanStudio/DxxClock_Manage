<?
$act = isset($_GET['Act']) ? daddslashes($_GET['Act']) : null;
@header('Content-Type: application/json; charset=UTF-8');

?>